JohnDoe Free Bootstrap landing page for personal and commercial use. Designed with ♥️ and creativity by Devcrud.com 

Product Page: https://wwww.devcrud.com/

Credits:

    Demo Images:
        Unsplash:       	(https://www.unsplash.com)

    Icons:
		Themify Icons: 		(https://themify.me/themify-icons)

	Other:
		JQuery: 			(https://www.jquery.com)
		Bootstrap: 			(https://www.getbootstrap.com)
		Bootstrap Affix: 	(http://getbootstrap.com/javascript/#affix)  
		Isotope: 			(https://isotope.metafizzy.co/) 
		Google Maps:		(https://maps.google.com)
